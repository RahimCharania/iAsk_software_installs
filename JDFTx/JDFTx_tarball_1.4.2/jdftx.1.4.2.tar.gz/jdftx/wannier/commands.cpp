/*-------------------------------------------------------------------
Copyright 2011 Ravishankar Sundararaman

This file is part of JDFTx.

JDFTx is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

JDFTx is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with JDFTx.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------*/

#include <commands/minimize.h>
#include <wannier/Wannier.h>
#include <core/LatticeUtils.h>

enum WannierMember
{	WM_localizationMeasure,
	WM_precond,
	WM_bStart,
	WM_outerWindow,
	WM_innerWindow,
	WM_frozenCenters,
	WM_saveWfns,
	WM_saveWfnsRealSpace,
	WM_saveMomenta,
	WM_saveSpin,
	WM_slabWeight,
	WM_loadRotations,
	WM_eigsOverride,
	WM_numericalOrbitals,
	WM_numericalOrbitalsOffset,
	WM_phononSup,
	WM_rSmooth,
	WM_wrapWignerSeitz,
	WM_spinMode,
	WM_delim
};

EnumStringMap<WannierMember> wannierMemberMap
(	WM_localizationMeasure, "localizationMeasure",
	WM_precond, "precondition",
	WM_bStart, "bStart",
	WM_outerWindow, "outerWindow",
	WM_innerWindow, "innerWindow",
	WM_frozenCenters, "frozenCenters",
	WM_saveWfns, "saveWfns",
	WM_saveWfnsRealSpace, "saveWfnsRealSpace",
	WM_saveMomenta, "saveMomenta",
	WM_saveSpin, "saveSpin",
	WM_slabWeight, "slabWeight",
	WM_loadRotations, "loadRotations",
	WM_eigsOverride, "eigsOverride",
	WM_numericalOrbitals, "numericalOrbitals",
	WM_numericalOrbitalsOffset, "numericalOrbitalsOffset",
	WM_phononSup, "phononSupercell",
	WM_rSmooth, "rSmooth",
	WM_wrapWignerSeitz, "wrapWignerSeitz",
	WM_spinMode, "spinMode"
);

EnumStringMap<Wannier::LocalizationMeasure> localizationMeasureMap
(	Wannier::LM_FiniteDifference, "FiniteDifference",
	Wannier::LM_RealSpace, "RealSpace"
);

EnumStringMap<Wannier::SpinMode> spinModeMap
(	Wannier::SpinUp, "Up",
	Wannier::SpinDn, "Dn",
	Wannier::SpinAll, "All"
);


struct CommandWannier : public Command
{
	CommandWannier() : Command("wannier", "wannier")
	{
		format = "<key1> <args1...>  <key2> <args2...>  ...";
		comments =
			"%Control calculation and output of maximally-localized Wannier functions \\cite MLWF.\n"
			"The possible <key>'s and their corresponding arguments are:\n"
			"\n+ localizationMeasure FiniteDifference | RealSpace\n\n"
			"   Controls how the localization of the %Wannier functions is calculated.\n"
			"   The finite-difference reciprocal space measure of Marzari and Vanderbilt\n"
			"   (default) is inexpensive, but its error scales as Nkpoints^(-2./3).\n"
			"   The real space version is slower but its error scales as exp(-Nkpoints^(1/3)),\n"
			"   and is preferable for quantitative applications. Note that the real-space version\n"
			"   is not translationally invariant and wraps on a superlattice Wigner-Seitz cell\n"
			"   centered at the origin.\n"
			"\n+ precondition yes|no\n\n"
			"   Whether to use an inverse-Hemholtz preconditioner for the minimization.\n"
			"   Affects only the FiniteDifference localizationMeasure. (default: no)\n"
			"\n+ bStart <band>\n\n"
			"   For fixed band calculations, 0-based index of lowest band used.\n"
			"   The number of bands equals the number of wannier-centers specified.\n"
			"   Default: 0. Use in insulator calculations to ignore semi-core orbitals.\n"
			"\n+ outerWindow <eMin> <eMax>\n\n"
			"   Energy window within which bands contribute to wannier functions \\cite MLWFmetal.\n"
			"   bStart is ignored if outerWindow is specified.\n"
			"\n+ innerWindow <eMin> <eMax>\n\n"
			"   Inner energy window within which bands are used exactly \\cite MLWFmetal.\n"
			"   Requires outerWindow, and innerWindow must be its subset.\n"
			"\n+ frozenCenters <nFrozen> <filename>\n\n"
			"   Include frozen %Wannier centers imported as unitary rotations from <filename>\n"
			"   (.mlwfU output from another wannier run on the same jdftx state), and force\n"
			"   the current centers to be orthogonal to the imported ones. Note that all output\n"
			"   of this run will include the frozen as well as new centers for convenience.\n"
			"   \n"
			"   Requires innerWindow if outerWindow is present, and the frozen centers\n"
			"   must lie entirely within the inner window or fixed band range. (Effectively,\n" 
			"   the outer window used in generating the frozen centers must be a subset of\n"
			"   the present inner window / fixed band range.)\n"
			"\n+ saveWfns yes|no\n\n"
			"   Whether to write supercell wavefunctions in a spherical reciprocal-space basis.\n"
			"   Default: no.\n"
			"\n+ saveWfnsRealSpace yes|no\n\n"
			"   Whether to write supercell wavefunctions band-by-band in real space (can be enormous).\n"
			"   Default: no.\n"
			"\n+ saveMomenta yes|no\n\n"
			"   Whether to write momentum matrix elements in the same format as Hamiltonian.\n"
			"   The output is real and antisymmetric (drops the iota so as to half the output size).\n"
			"   Default: no.\n"
			"\n+ saveSpin yes|no\n\n"
			"   Whether to write spin matrix elements (for non-collinear calculations only).\n"
			"   Default: no.\n"
			"\n+ slabWeight <z0> <zH> <zSigma>\n\n"
			"   If specified, output the Wannier matrix elements of a slab weight function\n"
			"   centered at z0 (lattice coordinates) with half-width zH (lattice coordinates)\n"
			"   and Gaussian/erfc smoothness zSigma in bohrs. (Default: none)\n"
			"\n+ loadRotations yes|no\n\n"
			"   Whether to load rotations (.mlwU and .mlwfU2) from a previous %Wannier run.\n"
			"   Default: no.\n"
			"\n+ eigsOverride <filename>\n\n"
			"   Optionally read an alternate eigenvalues file to over-ride those from the total\n"
			"   energy calculation. Useful for generating Wannier Hamiltonians using eigenvalues\n"
			"   from another DFT or a many-body perturbation theory code.\n"
			"\n+ numericalOrbitals <filename>\n\n"
			"   Load numerical orbitals from <filename> with basis described in <filename>.header\n"
			"   that can then be used as trial orbitals. The reciprocal space wavefunction output\n"
			"   of wannier is precisely in this format, so that supercell %Wannier calculations can\n"
			"   be initialized from previously calculated bulk / unit cell %Wannier functions.\n"
			"\n+ numericalOrbitalsOffset <x0> <x1> <x2>\n\n"
			"   Origin of the numerical orbitals in lattice coordinates of the input.\n"
			"   The default [ .5 .5 .5 ] (cell center) is appropriate for output from wannier.\n"
			"\n+ phononSupercell <N0> <N1> <N2>\n\n"
			"   If specified, wannier will read in output (phononHsub and phononBasis) of the\n"
			"   phonon code with this supercell and output Wannierized electron-phonon matrix\n"
			"   elements (mlwfHePh). This file will contain matrices for pairs of cells in the\n"
			"   order specified in the mlwfCellMapSqPh output file, with an outer loop over\n"
			"   the nuclear displacement modes in phononBasis.\n"
			"\n+ rSmooth <rSmooth>\n\n"
			"   Width in bohrs of the supercell boundary region over which matrix elements are smoothed.\n"
			"   If phononSupercell is specified to process phonon quantities, the rSmooth specified here\n"
			"   must exactly match the value specified in the calculation in command phonon.\n"
			"\n+ wrapWignerSeitz yes|no\n\n"
			"   If yes, wrap Wannier centers (and atom positions for phonon modes) to a Wigner-Seitz cell\n"
			"   so as to minimize the number of cells in the Wannier-basis output.  As a consequence,\n"
			"   however, minimized Wannier centers may differ from the guesses by some lattice vector.\n"
			"   Default: no.\n"
			"\n+ spinMode" + spinModeMap.optionList() + "\n\n"
			"   If Up or Dn, only generate Wannier functions for that spin channel, allowing\n"
			"   different input files for each channel (independent centers, windows etc.).\n"
			"   Default: All, generate for all spin channels (only valid option for spintype != z-spin).";
		
		require("spintype");
	}

	void process(ParamList& pl, Everything& e)
	{	Wannier& wannier = ((WannierEverything&)e).wannier;
		while(true)
		{	WannierMember key; pl.get(key, WM_delim, wannierMemberMap, "key");
			if(key==WM_delim) break;
			switch(key)
			{	case WM_localizationMeasure:
					pl.get(wannier.localizationMeasure, Wannier::LM_FiniteDifference,  localizationMeasureMap, "localizationMeasure", true);
					break;
				case WM_precond:
					pl.get(wannier.precond, false, boolMap, "precondition", true);
					break;
				case WM_bStart:
					pl.get(wannier.bStart, 0, "band", true);
					break;
				case WM_outerWindow:
					pl.get(wannier.eOuterMin, 0., "eMin", true);
					pl.get(wannier.eOuterMax, 0., "eMax", true);
					wannier.outerWindow = true;
					break;
				case WM_innerWindow:
					pl.get(wannier.eInnerMin, 0., "eMin", true);
					pl.get(wannier.eInnerMax, 0., "eMax", true);
					wannier.innerWindow = true;
					break;
				case WM_frozenCenters:
					pl.get(wannier.nFrozen, 0, "nFrozen", true);
					pl.get(wannier.frozenUfilename, string(), "filename", true);
					if(wannier.nFrozen <= 0) throw string("nFrozen must be > 0");
					break;
				case WM_saveWfns:
					pl.get(wannier.saveWfns, false, boolMap, "saveWfns", true);
					break;
				case WM_saveWfnsRealSpace:
					pl.get(wannier.saveWfnsRealSpace, false, boolMap, "saveWfnsRealSpace", true);
					break;
				case WM_saveMomenta:
					pl.get(wannier.saveMomenta, false, boolMap, "saveMomenta", true);
					break;
				case WM_saveSpin:
					pl.get(wannier.saveSpin, false, boolMap, "saveSpin", true);
					if(wannier.saveSpin and not e.eInfo.isNoncollinear())
						throw string("saveSpin requires noncollinear spin mode");
					break;
				case WM_slabWeight:
					pl.get(wannier.z0, 0., "z0", true);
					pl.get(wannier.zH, 0., "zH", true);
					pl.get(wannier.zSigma, 0., "zSigma", true);
					break;
				case WM_loadRotations:
					pl.get(wannier.loadRotations, false, boolMap, "loadRotations", true);
					break;
				case WM_eigsOverride:
					pl.get(wannier.eigsFilename, string(), "filename", true);
					break;
				case WM_numericalOrbitals:
					pl.get(wannier.numericalOrbitalsFilename, string(), "filename", true);
					break;
				case WM_numericalOrbitalsOffset:
					pl.get(wannier.numericalOrbitalsOffset[0], 0., "x0", true);
					pl.get(wannier.numericalOrbitalsOffset[1], 0., "x1", true);
					pl.get(wannier.numericalOrbitalsOffset[2], 0., "x2", true);
					break;
				case WM_phononSup:
					pl.get(wannier.phononSup[0], 0, "N0", true);
					pl.get(wannier.phononSup[1], 0, "N1", true);
					pl.get(wannier.phononSup[2], 0, "N2", true);
					break;
				case WM_rSmooth:
					pl.get(wannier.rSmooth, 1., "rSmooth", true);
					if(wannier.rSmooth <= 0.) throw string("<rSmooth> must be positive");
					break;
				case WM_wrapWignerSeitz:
					pl.get(wannier.wrapWS, false, boolMap, "wrapWignerSeitz", true);
					break;
				case WM_spinMode:
					pl.get(wannier.spinMode, Wannier::SpinAll,  spinModeMap, "spinMode", true);
					if(e.eInfo.spinType!=SpinZ && wannier.spinMode!=Wannier::SpinAll)
						throw string("<spinMode> must be All for spintype != z-spin");
					break;
				case WM_delim: //should never be encountered
					break;
			}
		}
	}

	void printStatus(Everything& e, int iRep)
	{	const Wannier& wannier = ((const WannierEverything&)e).wannier;
		logPrintf(" \\\n\tlocalizationMeasure %s", localizationMeasureMap.getString(wannier.localizationMeasure));
		logPrintf(" \\\n\tprecondition %s", boolMap.getString(wannier.precond));
		logPrintf(" \\\n\tsaveWfns %s", boolMap.getString(wannier.saveWfns));
		logPrintf(" \\\n\tsaveWfnsRealSpace %s", boolMap.getString(wannier.saveWfnsRealSpace));
		logPrintf(" \\\n\tsaveMomenta %s", boolMap.getString(wannier.saveMomenta));
		logPrintf(" \\\n\tsaveSpin %s", boolMap.getString(wannier.saveSpin));
		if(wannier.zH)
			logPrintf(" \\\n\tslabWeight %lg %lg %lg", wannier.z0, wannier.zH, wannier.zSigma);
		logPrintf(" \\\n\tloadRotations %s", boolMap.getString(wannier.loadRotations));
		if(wannier.eigsFilename.length())
			logPrintf(" \\\n\teigsFilename %s", wannier.eigsFilename.c_str());
		if(wannier.outerWindow)
		{	logPrintf(" \\\n\touterWindow %lg %lg", wannier.eOuterMin, wannier.eOuterMax);
			if(wannier.innerWindow)
				logPrintf(" \\\n\tinnerWindow %lg %lg", wannier.eInnerMin, wannier.eInnerMax);
		}
		else
		{	logPrintf(" \\\n\tbStart %d", wannier.bStart);
		}
		if(wannier.nFrozen)
			logPrintf(" \\\n\tfrozenCenters %d %s", wannier.nFrozen, wannier.frozenUfilename.c_str());
		if(wannier.numericalOrbitalsFilename.length())
		{	logPrintf(" \\\n\tnumericalOrbitals %s", wannier.numericalOrbitalsFilename.c_str());
			const vector3<>& offs = wannier.numericalOrbitalsOffset;
			logPrintf(" \\\n\tnumericalOrbitalsOffset %lg %lg %lg", offs[0], offs[1], offs[2]);
		}
		if(wannier.phononSup.length_squared())
			logPrintf(" \\\n\tphononSupercell %d %d %d", wannier.phononSup[0], wannier.phononSup[1], wannier.phononSup[2]);
		logPrintf(" \\\n\trSmooth %lg", wannier.rSmooth);
		logPrintf(" \\\n\twrapWignerSeitz %s", boolMap.getString(wannier.wrapWS));
		logPrintf(" \\\n\tspinMode %s", spinModeMap.getString(wannier.spinMode));
	}
}
commandWannier;


struct CommandWannierCenter : public Command
{
	CommandWannierCenter(string suffix=string()) : Command("wannier-center" + suffix, "wannier")
	{
		format = "<aorb1> [<aorb2> ...]";
		comments =
			"Specify trial orbital for a wannier function as a linear combination of\n"
			"atomic orbitals <aorb*>. The syntax for each <aorb> is one of:\n"
			"\n"
			" +  <species> <atom> <orbDesc> [<coeff>=1.0]\n"
			" +  Gaussian <x0> <x1> <x2>  [<sigma>=1] [<orbDesc>=s] [<coeff>=1.0]\n"
			" +  Numerical <b>  [<x0> <x1> <x2>] [<coeff>=1.0]\n"
			"\n"
			"The first syntax selects an atomic orbital of the <atom>th atom\n"
			"(1-based index) of species named <species>.\n"
			"Orbital code <orbDesc> is as in command density-of-states,\n"
			"but only codes for individual orbitals eg. px, dxy can be used.\n"
			"(Codes for a set of orbitals eg. p, d are not allowed here.)\n"
			"\n"
			"The second syntax selects a Gaussian orbital of sigma = n*<sigma> bohrs,\n"
			"where n is the principal quantum number in <orbDesc> (default 1),\n"
			"and with angular quantum numbers as specified in <orbDesc> (default s).\n"
			"The orbital will be centered at <x0>,<x1>,<x2> in the coordinate system set by coords-type.\n"
			"\n"
			"The third syntax selects numerical orbital number <b> (0-based index)\n"
			"read from the file specified in command wannier, and optionally\n"
			"offsets it to the location specified by <x0>,<x1>,<x2>.\n"
			"\n"
			"When using multiple orbitals (of any type) in a linear combination,\n"
			"specify all default parameters explicitly before providing <coeff>.\n"
			"\n"
			"Specify this command once for each Wannier function.\n"
			"\n"
			"Examples:\n"
			"+ wannier-center Cu 1 dxy            #dxy orbital on first Cu atom.\n"
			"+ wannier-center Gaussian 0 0 0 1.5  #Gaussian orbital at origin with sigma=1.5.\n"
			"+ wannier-center Numerical 1         #Second numerical orbital without offset.\n"
			"+ wannier-center Cu 1 dxy 0.707  Numerical 1 0 0 0 0.707  #Linear combination of first and third example above.";
		
		allowMultiple = true;
		require("wannier-initial-state");
		require("wannier-dump-name");
		require("ion");
		require("spintype");
	}

	void process(ParamList& pl, Everything& e)
	{	Wannier& wannier = ((WannierEverything&)e).wannier;
		Wannier::TrialOrbital t;
		while(true)
		{	Wannier::AtomicOrbital ao;
			string key; pl.get(key, string(), "species");
			if(!key.size()) break;
			bool isGaussian = (key=="Gaussian");
			bool isNumerical = (key=="Numerical");
			if(isGaussian || isNumerical)
			{	if(isNumerical)
				{	pl.get(ao.numericalOrbIndex, -1, "b", true); //required orbital index
					if(ao.numericalOrbIndex<0) throw string("0-based numerical orbital index must be non-negative");
				}
				//Get position:
				pl.get(ao.r[0], 0., "x0", isGaussian); //position required for Gaussian, optional for numerical
				pl.get(ao.r[1], 0., "x1", isGaussian);
				pl.get(ao.r[2], 0., "x2", isGaussian);
				//Transform to lattice coordinates if necessary:
				if(e.iInfo.coordsType == CoordsCartesian)
					ao.r = inv(e.gInfo.R)*ao.r;
				if(isGaussian)
					pl.get(ao.sigma, 1., "sigma"); //optional sigma
			}
			else //must be atomic orbital
			{	for(int sp=0; sp<int(e.iInfo.species.size()); sp++)
					if(e.iInfo.species[sp]->name == key)
					{	ao.sp = sp;
						break;
					}
				if(ao.sp<0) //defaults to -1 in AtomicOrbital()
					throw string("<species> must match one of the atom-type names in the calculation, or 'Gaussian' or Numerical'");
				pl.get(ao.atom, 0, "atom", true);
				if(ao.atom <= 0) throw string("1-based atom index must be positive");
				ao.atom--; //store as zero-based index internally
				wannier.needAtomicOrbitals = true;
			}
			//Read orbital description if needed:
			if(!isNumerical) //i.e. Gaussian or atomic orbital
			{	string orbDesc;
				pl.get(orbDesc, string(), "orbDesc");
				if(orbDesc.length())
				{	ao.orbitalDesc.parse(orbDesc);
					if(ao.orbitalDesc.m > ao.orbitalDesc.l)
						throw string("Must specify a specific projection eg. px,py (not just p)");
				}
				else 
				{	if(isGaussian)
					{	//default s orbital
						ao.orbitalDesc.l = 0;
						ao.orbitalDesc.m = 0;
						ao.orbitalDesc.n = 0;
						ao.orbitalDesc.s = 0;
						ao.orbitalDesc.spinType = SpinNone;
					}
					else throw string("Must specify <orbDesc> explicitly for atomic orbitals.\n");
				}
				if((e.eInfo.spinType==SpinOrbit || e.eInfo.spinType==SpinVector) && ao.orbitalDesc.spinType==SpinNone)
					throw string("Must specify an explicit spin projection for noncollinear modes");
				if((e.eInfo.spinType==SpinNone || e.eInfo.spinType==SpinZ) && ao.orbitalDesc.spinType!=SpinNone)
					throw string("Orbital projections must not specify spin for collinear modes");
				if(ao.orbitalDesc.spinType==SpinOrbit && ao.atom<0)
					throw string("Relativistic (l,j,mj) orbital projections must be centered on an atom");
			}
			pl.get(ao.coeff, 1., "coeff");
			t.push_back(ao);
		}
		if(!t.size()) throw(string("Trial orbital for each center must contain at least one atomic orbital"));
		wannier.trialOrbitals.push_back(t);
	}

	void printStatus(Everything& e, int iRep)
	{	const Wannier& wannier = ((const WannierEverything&)e).wannier;
		const Wannier::TrialOrbital& t = wannier.trialOrbitals[iRep];
		for(const Wannier::AtomicOrbital& ao: t)
		{	if(t.size()>1) logPrintf(" \\\n\t");
			bool isNumerical = (ao.numericalOrbIndex>=0);
			bool isGaussian = (ao.sigma>0.);
			if(isGaussian || isNumerical)
			{	if(isNumerical)
					logPrintf("Numerical %d", ao.numericalOrbIndex);
				else
					logPrintf("Gaussian");
				vector3<> r = ao.r;
				if(e.iInfo.coordsType == CoordsCartesian)
					r = e.gInfo.R * r; //report cartesian positions
				logPrintf(" %lg %lg %lg", r[0], r[1], r[2]);
				if(isGaussian)
					logPrintf(" %lg", ao.sigma);
			}
			else //atomic
			{	logPrintf("%s %d", e.iInfo.species[ao.sp]->name.c_str(), ao.atom+1);
			}
			if(!isNumerical) //Gaussian or atomic:
			{	logPrintf(" %s", string(ao.orbitalDesc).c_str());
			}
			logPrintf("  %lg", ao.coeff);
		}
	}
}
commandWannierCenter;


struct CommandWannierCenterPinned : public CommandWannierCenter
{
	CommandWannierCenterPinned(string suffix=string()) : CommandWannierCenter("-pinned")
	{	comments =
			"Same as command wannier-center, except that the minimizer tries to\n"
			"center this orbital at the specified guess positions (weighted mean\n"
			"of the orbital centers, if using a  linear combination). This can help\n"
			"improve the minimizer conditioning if the centers are known by symmetry.";
	}
	
	void process(ParamList& pl, Everything& e)
	{	Wannier& wannier = ((WannierEverything&)e).wannier;
		CommandWannierCenter::process(pl, e);
		Wannier::TrialOrbital& t = wannier.trialOrbitals.back();
		t.pinned = true;
	}
}
commandWannierCenterPinned;


struct CommandWannierMinimize : public CommandMinimize
{	CommandWannierMinimize() : CommandMinimize("wannier", "wannier") {}
    MinimizeParams& target(Everything& e)
	{	Wannier& wannier = ((WannierEverything&)e).wannier;
		return wannier.minParams;
	}
    void process(ParamList& pl, Everything& e)
	{	Wannier& wannier = ((WannierEverything&)e).wannier;
		wannier.minParams.energyDiffThreshold = 1e-8; //override default value (0.) in MinimizeParams.h
		wannier.minParams.dirUpdateScheme = MinimizeParams::LBFGS;
		CommandMinimize::process(pl, e);
	}
}
commandWannierMinimize;


struct CommandWannierFilenames : public Command
{	virtual string& getTarget(Everything&)=0; //derived class determines where to save the file
	
	CommandWannierFilenames(string cmdSuffix, string comment) : Command("wannier-"+cmdSuffix, "wannier")
	{	format = "<format>";
		comments = 
			"Control the filename pattern for wannier " + comment + ", where <format> must contain\n"
			"a single instance of $VAR, which will be substituted by the name of each variable.";
	}

	void process(ParamList& pl, Everything& e)
	{	string& target = getTarget(e);
		pl.get(target, string("$STAMP.$VAR"), "format");
		if(target.find("$VAR")==string::npos)
			throw "<format> = " + target + " doesn't contain the pattern $VAR";
	}

	void printStatus(Everything& e, int iRep)
	{	logPrintf("%s", getTarget(e).c_str());
	}
};

struct CommandWannierInitialState : public CommandWannierFilenames
{	CommandWannierInitialState() : CommandWannierFilenames("initial-state", "state initialization") {}
	string& getTarget(Everything& e) { return ((WannierEverything&)e).wannier.initFilename; }
}
commandWannierInitialState;

struct CommandWannierDumpName : public CommandWannierFilenames
{	CommandWannierDumpName() : CommandWannierFilenames("dump-name", "output") {}
	string& getTarget(Everything& e) { return ((WannierEverything&)e).wannier.dumpFilename; }
}
commandWannierDumpName;

