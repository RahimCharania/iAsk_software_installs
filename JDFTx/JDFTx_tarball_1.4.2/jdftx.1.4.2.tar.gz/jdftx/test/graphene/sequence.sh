#!/bin/bash
export runs="totalE bandstruct"
export nProcs="4"
