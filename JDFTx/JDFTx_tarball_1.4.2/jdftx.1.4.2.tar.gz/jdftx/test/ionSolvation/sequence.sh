#!/bin/bash
export runs="LinearPCM CANDLE"
export nProcs="1"
