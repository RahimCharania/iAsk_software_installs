#!/bin/bash
export runs="neutral charged"
export nProcs="4"
