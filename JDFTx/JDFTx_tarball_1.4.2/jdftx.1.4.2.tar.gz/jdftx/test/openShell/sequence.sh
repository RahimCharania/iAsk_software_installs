#!/bin/bash
export runs="Hatom O2"
export nProcs="2"
