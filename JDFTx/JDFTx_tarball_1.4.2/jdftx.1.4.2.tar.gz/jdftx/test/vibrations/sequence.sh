#!/bin/bash
export runs="H2_geometry H2_vibrations"
export nProcs="1"
