#!/bin/bash
export runs="NiO"
export nProcs="4"
