#!/bin/bash
export runs="Pt"
export nProcs="4"
