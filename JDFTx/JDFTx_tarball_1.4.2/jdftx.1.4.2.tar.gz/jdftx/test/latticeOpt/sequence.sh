#!/bin/bash
export runs="latticeOpt"
export nProcs="4"
