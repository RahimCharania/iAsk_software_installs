#!/bin/bash
export runs="totalE SCF"
export nProcs="4"
