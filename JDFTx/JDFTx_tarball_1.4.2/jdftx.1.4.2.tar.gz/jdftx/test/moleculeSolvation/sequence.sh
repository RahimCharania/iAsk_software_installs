#!/bin/bash
export runs="vacuum LinearPCM CANDLE"
export nProcs="1"
